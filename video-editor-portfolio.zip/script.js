document.addEventListener("DOMContentLoaded", () => {
  // 1. Mouse Glow Effect
  const glow = document.getElementById("cursor-glow")
  if (glow) {
    document.addEventListener("mousemove", (e) => {
      glow.style.left = `${e.clientX}px`
      glow.style.top = `${e.clientY}px`
      glow.style.opacity = "1"
    })
  }

  // 2. Scroll Reveal Animation
  const observerOptions = {
    threshold: 0.1,
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("active")
      }
    })
  }, observerOptions)

  document.querySelectorAll(".reveal-content, .work-item").forEach((el) => {
    observer.observe(el)
  })

  // 3. Filtering Logic for hardcoded items
  const filterButtons = document.querySelectorAll(".filter-btn")
  const workItems = document.querySelectorAll(".work-item")

  filterButtons.forEach((btn) => {
    btn.addEventListener("click", (e) => {
      // Update button styles
      filterButtons.forEach((b) => b.classList.remove("active"))
      e.target.classList.add("active")

      const filterValue = e.target.getAttribute("data-filter")

      workItems.forEach((item) => {
        if (filterValue === "all" || item.getAttribute("data-category") === filterValue) {
          item.classList.remove("hidden")
          // Re-trigger animation if visible
          item.classList.add("active")
        } else {
          item.classList.add("hidden")
        }
      })
    })
  })
})
